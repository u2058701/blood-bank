<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="css/lightbox.css" rel="stylesheet" />
    <link href="StyleSheet.css" rel="stylesheet" type="text/css" />

    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!--slider-->
<link href="css/flexslider.css" rel="stylesheet" type="text/css" media="all" />
     <script src="js/jquery-1.11.0.min.js"></script>
	<script src="js/lightbox.min.js"></script>
<script src="js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider.js" type="text/javascript"></script>
  
 <script type="text/javascript">
     $(function () {
         SyntaxHighlighter.all();
     });
     $(window).load(function () {
         $('.flexslider').flexslider({
             animation: "slide",
             animationLoop: false,
             itemWidth: 210,
             itemMargin: 5,
             minItems: 2,
             maxItems: 4,
             start: function (slider) {
                 $('body').removeClass('loading');
             }
         });
     });
  </script>
</head>

<body>
<?php include('Admin/function.php'); ?>
<?php require('header.php');?>
   
<div class="wrap">
    <div class="cont_main">
    	<div class="content">
             <table cellpadding="0" cellspacing="0" width="1100px" style="margin:auto">
                 <tr>            
                    <td>
            
                  <table cellpadding="0" cellspacing="0" width="100%">
                                <?php
                    $cn=makeconnection();
                    $s="select * from donarregistration,bloodgroup where donarregistration.b_id='". $_REQUEST["bg"]."' and donarregistration.b_id=bloodgroup.bg_id";
                        $result=mysqli_query($cn,$s);
                        $r=mysqli_num_rows($result);
                        //echo $r;
                        $n=0;
                        while($data=mysqli_fetch_array($result))
                        {
                    ?>
                      <tr>
                          <td>
                              <table cellpadding="0" cellspacing="0" width="700px" height="150px" style="margin:auto; border:none;" class="tableborder">
                                  <tr>
                                      <td>
                                          <a href="doner_pic<?php echo $data[8] ?>"data-lightbox="image-1"> 
                                          <img src="doner_pic/<?php echo $data[8] ?>" height="100px" width="100px"/>
                                          </a>
                                        </td>
                                        <td>
                                            <table cellpadding="0">
                                                <tr>
                                                    <td class="title">Name</td>
                                                    <td><?php echo $data[1]; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="title">Gender</td>
                                                    <td><?php echo $data[2]; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="title">Mobile No:</td>
                                                    <td><?php echo $data[4]; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="title">Email</td>
                                                    <td><?php echo $data[6]; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="title">Blood Group</td>
                                                    <td><?php echo $data[10]; ?></td></tr>                                                    
                                                    
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <?php }
                        ?>
                    </table>
                   </td>
                </tr>
            </table>
        </div>
    </div>
</div>

       
        <div class="clear"></div>
<div class="ftr-bg">
<div class="wrap">
<div class="footer">
	<div class="f_nav">
		<ul>
			<li class="active"><a href="index.php">Home</a></li>			
			<li><a href="donar.php">Donor</a></li>
            <li><a href="login.php">log In</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contact.php">Contact Us</a></li>
			
            </ul>
	</div>
		<div class="copy">
			<p class="title">© All Rights Reserved</p>
		</div>
</div>
</div>
</div>
</body>
</html>