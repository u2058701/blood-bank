<div class="h_bg">
<div class="wrap">
<div class="header">
		<div class="logo">
			<h1><a href="index.php"><img src="Images/logo.png" alt=""></a></h1>
		</div>
		<div class="nav_bg">
		<ul class="nav">	
           	<li><a href="aboutus.php">About</a></li>
            <li><a href="camps.php">Camps</a></li>           
			<li><a href="requests.php">send Request</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="viewrequest.php">View Request</a></li>
            <li><a href="contact.php">Contact Us</a></li>
			<li><a href="registration.php">Donor Registration</a></li> 
            <li><a href="login.php">log In</a></li>
            </ul>
	   </div>
</div>
</div>
</div>